README.TXT

I have correctly implemeted an index page that displays all high scores. 
I have correctly implemented user search that brings up a new page with the selected user's high scores. 
I have correctly implemented highscores.json of the top 10 scores in sorted order.

I worked with Evan Ferber, and received help from Eliot Alter and Trevor John. 

This project took me about 12 hours of work. 